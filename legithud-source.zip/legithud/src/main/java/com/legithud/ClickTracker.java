package com.legithud;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks real mouse click timestamps (fed by MouseMixin) to compute
 * an accurate clicks-per-second value over a rolling 1 second window.
 * This only ever records clicks the mixin sees come from GLFW - it does
 * not generate or accelerate clicks, so it can't be used as an autoclicker.
 */
public class ClickTracker {
    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();

    public static void recordLeftClick() {
        record(leftClicks);
    }

    public static void recordRightClick() {
        record(rightClicks);
    }

    private static void record(Deque<Long> deque) {
        long now = System.currentTimeMillis();
        deque.addLast(now);
        prune(deque, now);
    }

    private static void prune(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    public static int getLeftCps() {
        prune(leftClicks, System.currentTimeMillis());
        return leftClicks.size();
    }

    public static int getRightCps() {
        prune(rightClicks, System.currentTimeMillis());
        return rightClicks.size();
    }
}
