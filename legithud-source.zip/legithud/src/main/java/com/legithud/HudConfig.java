package com.legithud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores draggable positions for each HUD element and persists them
 * to config/legithud.json so they survive between game sessions.
 */
public class HudConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("legithud.json");

    public static class Pos {
        public int x;
        public int y;

        public Pos(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    public boolean hudLocked = true; // locked by default so it doesn't move accidentally
    public boolean hitboxesEnabled = false;
    public boolean rainbowTheme = true;
    public boolean showConfigPanel = true;
    public Map<String, Boolean> featureEnabled = new HashMap<>();
    public Map<String, Pos> positions = new HashMap<>();

    public boolean isEnabled(String featureId) {
        return featureEnabled.computeIfAbsent(featureId, k -> true);
    }

    public void setEnabled(String featureId, boolean value) {
        featureEnabled.put(featureId, value);
    }

    private static HudConfig instance;

    public static HudConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public Pos getPos(String key, int defaultX, int defaultY) {
        return positions.computeIfAbsent(key, k -> new Pos(defaultX, defaultY));
    }

    public void setPos(String key, int x, int y) {
        Pos p = positions.computeIfAbsent(key, k -> new Pos(x, y));
        p.x = x;
        p.y = y;
    }

    private static HudConfig load() {
        try {
            if (Files.exists(FILE)) {
                String json = Files.readString(FILE);
                HudConfig cfg = GSON.fromJson(json, HudConfig.class);
                if (cfg != null) {
                    if (cfg.positions == null) cfg.positions = new HashMap<>();
                    if (cfg.featureEnabled == null) cfg.featureEnabled = new HashMap<>();
                    return cfg;
                }
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            // fall through to defaults
        }
        return new HudConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[LegitHUD] Failed to save config: " + e.getMessage());
        }
    }
}
