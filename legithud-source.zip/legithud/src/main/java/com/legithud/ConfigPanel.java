package com.legithud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/**
 * Left-side panel listing every HUD feature with an on/off state -
 * like a config list. Purely a display/toggle list for this mod's own
 * legitimate features (CPS, FPS, armor durability, hitbox view, theme).
 */
public class ConfigPanel {
    private static final String PANEL_ID = "config_panel";
    private static final int DEFAULT_X = 10;
    private static final int DEFAULT_Y = 200;
    private static final int PADDING = 4;
    private static final int LINE_HEIGHT = 11;
    private static final int BG_COLOR = 0xA0000000;

    public record Row(String featureId, String label) {}

    public static final List<Row> ROWS = List.of(
            new Row(HudElement.CPS.id, "CPS Counter"),
            new Row(HudElement.FPS_PING.id, "FPS / Ping"),
            new Row(HudElement.ARMOR_DURABILITY.id, "Armor Durability"),
            new Row(HudElement.HELD_ITEMS.id, "Held Items"),
            new Row("hitboxes_row", "Hitbox View (vanilla)"),
            new Row("rainbow_theme_row", "Rainbow Theme")
    );

    /** Renders the panel. If interactive is true (edit mode), rows are clickable. Returns row bounding boxes for hit-testing. */
    public static int[][] render(DrawContext ctx, MinecraftClient client, boolean editMode) {
        HudConfig cfg = HudConfig.get();
        if (!cfg.showConfigPanel && !editMode) {
            return new int[0][];
        }

        HudConfig.Pos pos = cfg.getPos(PANEL_ID, DEFAULT_X, DEFAULT_Y);
        TextRenderer font = client.textRenderer;

        String title = "LegitHUD Config";
        int maxWidth = font.getWidth(title);
        for (Row row : ROWS) {
            String text = row.label() + " [" + (isRowOn(cfg, row) ? "ON" : "OFF") + "]";
            maxWidth = Math.max(maxWidth, font.getWidth(text));
        }
        int boxWidth = maxWidth + PADDING * 2;
        int boxHeight = (ROWS.size() + 1) * LINE_HEIGHT + PADDING * 2;

        ctx.fill(pos.x, pos.y, pos.x + boxWidth, pos.y + boxHeight, BG_COLOR);

        int titleColor = cfg.rainbowTheme ? RainbowUtil.getColor(1.0f) : 0xFFFFFFFF;
        int y = pos.y + PADDING;
        ctx.drawText(font, title, pos.x + PADDING, y, titleColor, true);
        y += LINE_HEIGHT;

        int[][] rowBoxes = new int[ROWS.size()][4];
        for (int i = 0; i < ROWS.size(); i++) {
            Row row = ROWS.get(i);
            boolean on = isRowOn(cfg, row);
            String text = row.label() + " [" + (on ? "ON" : "OFF") + "]";
            int color = on
                    ? (cfg.rainbowTheme ? RainbowUtil.getColorOffset(1.0f, i * 0.12f) : 0xFF55FF55)
                    : 0xFF808080;
            ctx.drawText(font, text, pos.x + PADDING, y, color, true);
            rowBoxes[i] = new int[]{pos.x, y, boxWidth, LINE_HEIGHT};
            y += LINE_HEIGHT;
        }

        return rowBoxes;
    }

    /** Computes row hit-boxes without rendering anything - safe to call during input handling. */
    public static int[][] measureRows(MinecraftClient client) {
        HudConfig cfg = HudConfig.get();
        HudConfig.Pos pos = cfg.getPos(PANEL_ID, DEFAULT_X, DEFAULT_Y);
        TextRenderer font = client.textRenderer;

        String title = "LegitHUD Config";
        int maxWidth = font.getWidth(title);
        for (Row row : ROWS) {
            String text = row.label() + " [" + (isRowOn(cfg, row) ? "ON" : "OFF") + "]";
            maxWidth = Math.max(maxWidth, font.getWidth(text));
        }
        int boxWidth = maxWidth + PADDING * 2;

        int y = pos.y + PADDING + LINE_HEIGHT; // skip title line
        int[][] rowBoxes = new int[ROWS.size()][4];
        for (int i = 0; i < ROWS.size(); i++) {
            rowBoxes[i] = new int[]{pos.x, y, boxWidth, LINE_HEIGHT};
            y += LINE_HEIGHT;
        }
        return rowBoxes;
    }

    private static boolean isRowOn(HudConfig cfg, Row row) {
        return switch (row.featureId()) {
            case "hitboxes_row" -> cfg.hitboxesEnabled;
            case "rainbow_theme_row" -> cfg.rainbowTheme;
            default -> cfg.isEnabled(row.featureId());
        };
    }

    /** Toggles the row at the given index and applies the effect immediately. */
    public static void toggleRow(int index, MinecraftClient client) {
        if (index < 0 || index >= ROWS.size()) return;
        HudConfig cfg = HudConfig.get();
        Row row = ROWS.get(index);
        switch (row.featureId()) {
            case "hitboxes_row" -> {
                cfg.hitboxesEnabled = !cfg.hitboxesEnabled;
                client.debugRenderer.toggleHitboxes();
            }
            case "rainbow_theme_row" -> cfg.rainbowTheme = !cfg.rainbowTheme;
            default -> cfg.setEnabled(row.featureId(), !cfg.isEnabled(row.featureId()));
        }
        cfg.save();
    }

    public static String panelId() {
        return PANEL_ID;
    }
}
