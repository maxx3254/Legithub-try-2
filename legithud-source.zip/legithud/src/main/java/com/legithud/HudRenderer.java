package com.legithud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

import java.util.List;

public class HudRenderer {
    private static final int PADDING = 4;
    private static final int LINE_HEIGHT = 10;
    private static final int BG_COLOR = 0x90000000; // semi-transparent black
    private static final int BORDER_COLOR_EDIT = 0xFFFFFF00; // yellow border in edit mode
    private static final int TEXT_COLOR_STATIC = 0xFFFFFFFF;

    /** Renders one element's box at its configured position. Returns the box width/height for hit-testing in edit mode. */
    public static int[] render(DrawContext ctx, MinecraftClient client, HudElement element, boolean editMode) {
        HudConfig cfg = HudConfig.get();

        // Respect per-feature on/off toggles (from the config side panel) when not in edit mode
        if (!editMode && !cfg.isEnabled(element.id)) {
            return new int[]{0, 0, 0, 0};
        }

        HudConfig.Pos pos = cfg.getPos(element.id, element.defaultX, element.defaultY);
        TextRenderer font = client.textRenderer;

        List<String> lines = editMode
                ? List.of(element.label + " (drag me)")
                : element.contentSupplier.apply(client);

        if (lines.isEmpty()) {
            return new int[]{pos.x, pos.y, 0, 0};
        }

        int maxWidth = 0;
        for (String line : lines) {
            maxWidth = Math.max(maxWidth, font.getWidth(line));
        }
        int boxWidth = maxWidth + PADDING * 2;
        int boxHeight = lines.size() * LINE_HEIGHT + PADDING * 2;

        int textColor = TEXT_COLOR_STATIC;
        int borderColor = editMode ? BORDER_COLOR_EDIT : 0;

        if (cfg.rainbowTheme) {
            // Each element gets its own hue phase so the whole HUD doesn't flash in unison
            float phase = (element.ordinal() * 0.15f);
            textColor = RainbowUtil.getColorOffset(1.0f, phase);
            borderColor = RainbowUtil.getColorOffset(1.0f, phase);
        }

        ctx.fill(pos.x, pos.y, pos.x + boxWidth, pos.y + boxHeight, BG_COLOR);
        if (editMode || cfg.rainbowTheme) {
            drawBorder(ctx, pos.x, pos.y, boxWidth, boxHeight, borderColor);
        }

        int textY = pos.y + PADDING;
        for (String line : lines) {
            ctx.drawText(font, line, pos.x + PADDING, textY, textColor, true);
            textY += LINE_HEIGHT;
        }

        return new int[]{pos.x, pos.y, boxWidth, boxHeight};
    }

    /** Computes box size for an element without rendering anything - safe to call during input handling. */
    public static int[] measure(MinecraftClient client, HudElement element, boolean editMode) {
        TextRenderer font = client.textRenderer;
        List<String> lines = editMode
                ? List.of(element.label + " (drag me)")
                : element.contentSupplier.apply(client);

        if (lines.isEmpty()) {
            return new int[]{0, 0};
        }
        int maxWidth = 0;
        for (String line : lines) {
            maxWidth = Math.max(maxWidth, font.getWidth(line));
        }
        int boxWidth = maxWidth + PADDING * 2;
        int boxHeight = lines.size() * LINE_HEIGHT + PADDING * 2;
        return new int[]{boxWidth, boxHeight};
    }

    private static void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }
}
