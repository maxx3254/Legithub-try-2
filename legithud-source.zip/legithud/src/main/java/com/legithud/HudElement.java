package com.legithud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public enum HudElement {
    CPS("cps", "CPS", 10, 10, client -> {
        List<String> lines = new ArrayList<>();
        lines.add("CPS: " + ClickTracker.getLeftCps() + " (L) / " + ClickTracker.getRightCps() + " (R)");
        return lines;
    }),

    FPS_PING("fps_ping", "FPS / Ping", 10, 30, client -> {
        List<String> lines = new ArrayList<>();
        int fps = client.getCurrentFps();
        int ping = -1;
        if (client.player != null && client.getNetworkHandler() != null) {
            ClientPlayNetworkHandler handler = client.getNetworkHandler();
            PlayerListEntry entry = handler.getPlayerListEntry(client.player.getUuid());
            if (entry != null) {
                ping = entry.getLatency();
            }
        }
        lines.add("FPS: " + fps);
        lines.add("Ping: " + (ping >= 0 ? ping + "ms" : "N/A"));
        return lines;
    }),

    ARMOR_DURABILITY("armor_durability", "Armor Durability", 10, 60, client -> {
        List<String> lines = new ArrayList<>();
        if (client.player == null) return lines;

        String[] slotNames = {"Boots", "Legs", "Chest", "Helmet"};
        // player.getInventory().armor is ordered feet(0) -> head(3)
        for (int i = 0; i < 4; i++) {
            ItemStack stack = client.player.getInventory().armor.get(i);
            lines.add(slotNames[i] + ": " + durabilityString(stack));
        }
        return lines;
    }),

    HELD_ITEMS("held_items", "Held Items", 10, 130, client -> {
        List<String> lines = new ArrayList<>();
        if (client.player == null) return lines;
        ItemStack main = client.player.getMainHandStack();
        ItemStack off = client.player.getOffHandStack();
        lines.add("Main: " + itemName(main) + " " + durabilityString(main));
        lines.add("Off: " + itemName(off) + " " + durabilityString(off));
        return lines;
    });

    public final String id;
    public final String label;
    public final int defaultX;
    public final int defaultY;
    public final Function<MinecraftClient, List<String>> contentSupplier;

    HudElement(String id, String label, int defaultX, int defaultY, Function<MinecraftClient, List<String>> contentSupplier) {
        this.id = id;
        this.label = label;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
        this.contentSupplier = contentSupplier;
    }

    private static String itemName(ItemStack stack) {
        if (stack == null || stack.isEmpty() || stack.getItem() == Items.AIR) {
            return "Empty";
        }
        return stack.getName().getString();
    }

    private static String durabilityString(ItemStack stack) {
        if (stack == null || stack.isEmpty() || stack.getItem() == Items.AIR) {
            return "-";
        }
        if (!stack.isDamageable()) {
            return "N/A";
        }
        int max = stack.getMaxDamage();
        int dmg = stack.getDamage();
        int remaining = max - dmg;
        int percent = max > 0 ? (int) ((remaining / (float) max) * 100) : 100;
        return remaining + "/" + max + " (" + percent + "%)";
    }
}
