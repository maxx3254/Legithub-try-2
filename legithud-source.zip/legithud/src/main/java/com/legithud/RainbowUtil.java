package com.legithud;

/**
 * Produces a smoothly cycling rainbow color for HUD text/borders.
 * Pure client-side visual flair - no gameplay effect.
 */
public class RainbowUtil {
    private static final float CYCLE_SECONDS = 6.0f;

    /** Returns an ARGB color that cycles through the hue wheel over time. */
    public static int getColor(float alpha) {
        float time = (System.currentTimeMillis() % (long) (CYCLE_SECONDS * 1000)) / (CYCLE_SECONDS * 1000f);
        int rgb = java.awt.Color.HSBtoRGB(time, 0.85f, 1.0f) & 0xFFFFFF;
        int a = (int) (alpha * 255) & 0xFF;
        return (a << 24) | rgb;
    }

    /** Same as getColor but offsets the hue phase so multiple elements don't all flash the same color at once. */
    public static int getColorOffset(float alpha, float phaseOffset) {
        float time = (System.currentTimeMillis() % (long) (CYCLE_SECONDS * 1000)) / (CYCLE_SECONDS * 1000f);
        float hue = (time + phaseOffset) % 1.0f;
        int rgb = java.awt.Color.HSBtoRGB(hue, 0.85f, 1.0f) & 0xFFFFFF;
        int a = (int) (alpha * 255) & 0xFF;
        return (a << 24) | rgb;
    }
}
