package com.legithud.mixin;

import com.legithud.ClickTracker;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the real GLFW mouse button callback so CPS reflects actual
 * physical clicks - nothing here generates or times clicks for the player.
 */
@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void legithud$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) {
            return;
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            ClickTracker.recordLeftClick();
        } else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            ClickTracker.recordRightClick();
        }
    }
}
