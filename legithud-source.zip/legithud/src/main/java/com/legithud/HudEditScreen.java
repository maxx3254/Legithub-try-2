package com.legithud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditScreen extends Screen {
    private HudElement dragging = null;
    private boolean draggingPanel = false;
    private int dragOffsetX;
    private int dragOffsetY;

    public HudEditScreen() {
        super(Text.literal("LegitHUD - Edit Mode"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // dark backdrop so boxes are easy to see and grab
        ctx.fill(0, 0, this.width, this.height, 0x60000000);

        for (HudElement element : HudElement.values()) {
            HudRenderer.render(ctx, this.client, element, true);
        }
        ConfigPanel.render(ctx, this.client, true);

        ctx.drawCenteredTextWithShadow(
                this.textRenderer,
                "Drag boxes to reposition. Click a config row to toggle it. Press the edit key (or ESC) to save & exit.",
                this.width / 2, 10, 0xFFFFFF00
        );

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            HudConfig cfg = HudConfig.get();

            // Check config panel rows first - clicking a row toggles it instead of dragging
            int[][] rowBoxes = ConfigPanel.measureRows(client);
            for (int i = 0; i < rowBoxes.length; i++) {
                int[] box = rowBoxes[i];
                if (box.length == 4 && mouseX >= box[0] && mouseX <= box[0] + box[2]
                        && mouseY >= box[1] && mouseY <= box[1] + box[3]) {
                    ConfigPanel.toggleRow(i, client);
                    return true;
                }
            }

            // Check panel header drag zone (the title line)
            HudConfig.Pos panelPos = cfg.getPos(ConfigPanel.panelId(), 10, 200);
            int[] panelSize = measurePanel();
            if (mouseX >= panelPos.x && mouseX <= panelPos.x + panelSize[0]
                    && mouseY >= panelPos.y && mouseY <= panelPos.y + 11) {
                draggingPanel = true;
                dragOffsetX = (int) mouseX - panelPos.x;
                dragOffsetY = (int) mouseY - panelPos.y;
                return true;
            }

            for (HudElement element : HudElement.values()) {
                HudConfig.Pos pos = cfg.getPos(element.id, element.defaultX, element.defaultY);
                int[] size = HudRenderer.measure(client, element, true);
                int w = size[0] > 0 ? size[0] : 80;
                int h = size[1] > 0 ? size[1] : 14;
                if (mouseX >= pos.x && mouseX <= pos.x + w && mouseY >= pos.y && mouseY <= pos.y + h) {
                    dragging = element;
                    dragOffsetX = (int) mouseX - pos.x;
                    dragOffsetY = (int) mouseY - pos.y;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;
            HudConfig.get().setPos(dragging.id, newX, newY);
            return true;
        }
        if (draggingPanel) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;
            HudConfig.get().setPos(ConfigPanel.panelId(), newX, newY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        draggingPanel = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private int[] measurePanel() {
        int width = client.textRenderer.getWidth("LegitHUD Config");
        for (ConfigPanel.Row row : ConfigPanel.ROWS) {
            width = Math.max(width, client.textRenderer.getWidth(row.label() + " [OFF]"));
        }
        return new int[]{width + 8, (ConfigPanel.ROWS.size() + 1) * 11 + 8};
    }

    @Override
    public void close() {
        HudConfig.get().save();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
