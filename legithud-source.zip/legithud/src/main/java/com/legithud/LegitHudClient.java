package com.legithud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class LegitHudClient implements ClientModInitializer {

    private KeyBinding editModeKey;
    private KeyBinding hitboxToggleKey;

    @Override
    public void onInitializeClient() {
        HudConfig.get(); // load config early

        editModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.legithud.edit_mode",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_BRACKET, // ']' by default - change in Controls menu
                "category.legithud"
        ));

        hitboxToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.legithud.toggle_hitboxes",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_APOSTROPHE, // "'" by default - change in Controls menu
                "category.legithud"
        ));

        // Render the HUD overlay every frame (this still draws behind chat/inventory screens,
        // same as vanilla hotbar/health does).
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;
            for (HudElement element : HudElement.values()) {
                HudRenderer.render(ctx, client, element, false);
            }
            ConfigPanel.render(ctx, client, false);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (editModeKey.wasPressed()) {
                if (!(client.currentScreen instanceof HudEditScreen)) {
                    client.setScreen(new HudEditScreen());
                } else {
                    client.currentScreen.close();
                }
            }

            while (hitboxToggleKey.wasPressed()) {
                HudConfig cfg = HudConfig.get();
                cfg.hitboxesEnabled = !cfg.hitboxesEnabled;
                // This just flips vanilla's own debug hitbox renderer (same one F3+B uses) -
                // it's a built-in vanilla feature, not a custom ESP.
                client.debugRenderer.toggleHitboxes();
                cfg.save();
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal("[LegitHUD] Hitboxes: " + (cfg.hitboxesEnabled ? "ON" : "OFF")),
                            true
                    );
                }
            }
        });
    }
}
