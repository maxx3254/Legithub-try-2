# LegitHUD

A clean, legal Fabric mod for Minecraft **1.21.11**: CPS counter, FPS, ping,
your own armor + held-item durability, a rainbow-themed HUD, a left-side
config panel showing which features are on, and a quick keybind to toggle
vanilla's built-in hitbox debug view (the same one F3+B already gives
everyone — this just makes it a single keypress).

Everything is client-side, cosmetic/informational only about **you**,
so it's allowed on essentially any server (no reach, no autoclicker,
no ESP on other players).

## What it does NOT do
- No enemy HP/armor/held-item display (Minecraft doesn't send that info
  to your client anyway — anything claiming to show it is faking it
  from hit-flash/sound patterns, which is exactly what gets clients
  flagged as cheats).
- No autoclicking — CPS is measured from your real mouse clicks only.
- No reach/killaura/velocity changes.

## Features
- **CPS counter** — real click tracking (left + right mouse)
- **FPS counter**
- **Ping display**
- **Your armor durability** (all 4 slots)
- **Your held item durability** (main hand + off hand)
- **Rainbow HUD theme** — text and borders smoothly cycle through hues
  (each box on its own phase so they don't all flash in sync); toggle
  it off any time from the config panel
- **Config panel** (left side) — lists every feature with an ON/OFF
  state; click a row in edit mode to toggle that feature instantly
- **Draggable HUD** — press `]` to enter edit mode, drag any box
  (including the config panel) anywhere on screen, press `]` or Esc
  to save and exit
- **Vanilla hitbox toggle** — press `'` to toggle (same feature as F3+B)
- Everything (positions, which features are on, theme choice) saves to
  `config/legithud.json` and reloads automatically next launch

Default keybinds (changeable in Options > Controls > LegitHUD):
| Key | Action |
|-----|--------|
| `]` | Toggle HUD edit/drag mode |
| `'` | Toggle vanilla hitboxes |

## Target version: Minecraft 1.21.11
1.21.11 is the **last obfuscated Java Edition release** before Mojang's
26.1 update switched to unobfuscated code and dropped Yarn mappings.
This project is pinned to the correct toolchain for that version:

| Component | Version |
|---|---|
| Minecraft | 1.21.11 |
| Fabric Loader | 0.18.1 |
| Fabric API | 0.139.5+1.21.11 |
| Yarn mappings | 1.21.11+build.4 |
| Fabric Loom | 1.14 |
| Java | 21 |

If Fabric ships a newer Loader/API patch for 1.21.11 by the time you
build this, feel free to bump `loader_version` / `fabric_version` in
`gradle.properties` — patch releases within 1.21.11 stay compatible.

## Building the mod (you need a PC with Java 21 + internet for this step)

Mobile devices (PojavLauncher) can **run** Fabric mods but can't easily
**build** them, so build the .jar on a computer first, then copy the
resulting file to your phone.

```bash
# From inside the legithud/ folder:
./gradlew build
```

Wait for it to finish (first run downloads Fabric Loom + dependencies,
takes a few minutes). Your compiled mod will be at:

```
build/libs/legithud-1.1.0.jar
```

(`chmod +x gradlew` first if you're on Mac/Linux and get a permission error.)

## Installing

### PC (regular Minecraft Launcher)
1. Install [Fabric Loader](https://fabricmc.net/use/) for Minecraft 1.21.11
2. Download **Fabric API 0.139.5+1.21.11** from Modrinth/CurseForge
3. Put both `fabric-api-*.jar` and `legithud-1.1.0.jar` into your
   `.minecraft/mods` folder
4. Launch the "fabric-loader-1.21.11" profile

### Mobile (PojavLauncher / Zalith Launcher)
1. Build the jar on a PC as above (or have someone build it for you)
2. Copy `legithud-1.1.0.jar` to your phone (via USB, cloud storage, etc.)
3. In PojavLauncher, install the **Fabric** loader for 1.21.11 through its
   built-in installer (Version selector > Install Fabric)
4. Download **Fabric API 0.139.5+1.21.11** and place it, plus
   `legithud-1.1.0.jar`, into PojavLauncher's `.minecraft/mods` folder
   (use the launcher's file manager or a root/Android file manager app)
5. Launch with the Fabric profile

## Real FPS gains on mobile (do this too)
- Add **Sodium** (Fabric, 1.21.11 build) to the same mods folder — biggest single FPS gain
- Add **Lithium** — server/game-logic optimization, free FPS
- In-game: lower render distance to 4-6 chunks, disable fancy graphics/clouds/particles
- In PojavLauncher settings: try the Vulkan (Zink) renderer if your device
  supports it — often faster than the default GL4ES on newer Android GPUs
- Don't over-allocate RAM — 2-3GB is usually the sweet spot on phones

## Still waiting on your PvP feature list
You mentioned specific PvP features to add on the left side but the
list didn't come through in chat — send it over and I'll fold in
whatever's legitimate (no reach/killaura/auto-anything).

